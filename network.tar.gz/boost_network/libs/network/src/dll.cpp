// (C) Copyright Pedro Lamarão 2005.
// Use, modification and distribution are subject to the
// Boost Software License, Version 1.0. (See accompanying file
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_NETWORK_SOURCE

#include <boost/config.hpp>

#if defined(BOOST_WINDOWS)

#include <boost/network/support/wsa_setup.hpp>

#pragma comment(lib, "ws2_32.lib")

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

using namespace boost::network;

namespace {
    wsa_setup* wsa;
}

extern "C" BOOL WINAPI
#if defined(__BORLANDC__)
    DllEntryPoint
#else
    DllMain
#endif
    (HINSTANCE /* hInstance */, DWORD dwReason, LPVOID /* lpReserved */ ) {
        switch(dwReason) {
            case DLL_PROCESS_ATTACH:
                wsa = new wsa_setup();
                break;
            case DLL_THREAD_ATTACH:
                break;
            case DLL_THREAD_DETACH:
                break;
            case DLL_PROCESS_DETACH:
                delete wsa;
                break;
            default:
                break;
        }
        return TRUE;
}

#endif // defined(BOOST_WINDOWS)

