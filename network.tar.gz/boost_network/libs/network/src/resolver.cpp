// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_NETWORK_SOURCE

#include <boost/network/resolver.hpp>
#include <boost/network/resolver_error.hpp>
#include <boost/network/detail/detail.hpp>

#if defined(BOOST_WINDOWS)
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <netdb.h>
#endif

namespace boost {

    namespace network {

        net_base::family
        resolved_address::family () const {
            using namespace detail;
            return translate_family(_M_a->ai_family);
        }

        sockaddr const*
        resolved_address::address () const {
            return _M_a->ai_addr;
        }

        int
        resolved_address::length () const {
            return _M_a->ai_addrlen;
        }

        resolver_result_iterator&
        resolver_result_iterator::operator++ () {
            _M_r = resolved_address(_M_r.handle()->ai_next);
            return *this;
        }

        resolver_result_container::size_type
        resolver_result_container::size () const {
            size_type count = 0;
            for (addrinfo const* a = _M_a; a != 0; a = a->ai_next)
                ++count;
            return count;
        }

        resolver_result_container::~resolver_result_container () {
            if (_M_a)
                freeaddrinfo(_M_a);
        }

        void
        resolver::resolve (std::string const& host,
                           std::string const& service) {
            addrinfo hint = { AI_PASSIVE, 0, 0, 0, 0, 0, 0, 0 };
            addrinfo* a;
            int r = getaddrinfo(host.empty() ? 0 : host.c_str(),
                                service.empty() ? 0 : service.c_str(),
                                &hint, &a);
            if (r != 0)
                throw resolver_error(r);

            // The temporary result_type created will free
            // the addrinfo* previously kept, if necessary, and transfer the
            // new addrinfo* into the result kept by the resolver.
            result_type tmp(a);
            _M_result.swap(tmp);
        }
    }

}

