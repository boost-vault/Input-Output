// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_NETWORK_SOURCE

#include <boost/network/listener.hpp>
#include <boost/network/net_error.hpp>
#include <boost/network/detail/detail.hpp>

#if defined(BOOST_WINDOWS)
# include <winsock2.h>
# include <ws2tcpip.h>
# define SHUT_RDWR SD_BOTH
#else
# include <fcntl.h>
# include <sys/socket.h>
# include <unistd.h>
# define INVALID_SOCKET (-1)
# define SOCKET_ERROR (-1)
#endif

namespace boost {

    namespace network {

        listener::listener (net_base::family f) : _M_d(INVALID_SOCKET) {
            using namespace detail;
            _M_d = ::socket(translate_family(f), SOCK_STREAM, 0);
            if (_M_d == INVALID_SOCKET)
                throw net_error();
        }

        listener::~listener () {
            ::shutdown(_M_d, SHUT_RDWR);
#if defined(BOOST_WINDOWS)
            ::closesocket(_M_d);
#else
            ::close(_M_d);
#endif

        }

        void
        listener::bind (sockaddr const* address, int length) {
            int r = ::bind(_M_d, address, length);
            if (r == SOCKET_ERROR)
                throw net_error();
        }

        void
        listener::listen () {
            int r = ::listen(_M_d, SOMAXCONN);
            if (r == SOCKET_ERROR)
                throw net_error();
        }

        net_base::descriptor_type
        listener::accept () {
            descriptor_type d = ::accept(_M_d, 0, 0);
            if (d == INVALID_SOCKET)
                throw net_error();
            return d;
        }

    }

}

