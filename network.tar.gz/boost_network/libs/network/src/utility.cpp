// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_NETWORK_SOURCE

#include <boost/network/utility.hpp>
#include <boost/network/detail/detail.hpp>

#if defined(BOOST_WINDOWS)
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <sys/types.h>
# include <sys/socket.h>
# include <arpa/inet.h>
#endif

namespace boost {
    
    namespace network {

#if defined(BOOST_WINDOWS)

#else

        std::basic_ostream<char, std::char_traits<char> >&
        operator<< (std::basic_ostream<char, std::char_traits<char> >& o,
                    sockaddr const* a) {
            const int size = INET6_ADDRSTRLEN;
            char buffer[size];
            
            /**
             * The point of passing a length together with sockaddr pointers
             * is precisely to avoid the kinds of mistakes one can make
             * while merely reinterpreting pointers like this...
             * 
             * But in pratice it's usable, and can be made safe with proper
             * use of sizeof inside this implementation.
             * 
             * But how do we return errors? address_error?
             */
            
            switch (a->sa_family) {
                case AF_INET:
                    sockaddr_in const* sin =
                        reinterpret_cast<sockaddr_in const*>(a);
                    inet_ntop(AF_INET, &sin->sin_addr, buffer, size);
                    break;
                case AF_INET6:
                    sockaddr_in6 const* sin6 =
                        reinterpret_cast<sockaddr_in6 const*>(a);
                    inet_ntop(AF_INET6, &sin6->sin6_addr, buffer, size);
                    break;
                default:
                    std::char_traits<char>::copy(buffer, "[unknown]", 9);
                    break; 
            }
            
            return o << buffer;
        }

#endif

    }
    
}

