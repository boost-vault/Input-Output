// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_NETWORK_SOURCE

#include <cerrno>
#include <cstdio>

#include <boost/network/talker.hpp>
#include <boost/network/net_error.hpp>
#include <boost/network/listener.hpp>
#include <boost/network/detail/detail.hpp>

#if defined(BOOST_WINDOWS)
# include <winsock2.h>
# include <ws2tcpip.h>
# define SHUT_RDWR SD_BOTH
namespace {
    const int send_recv_flag = 0;
}
#else
# include <fcntl.h>
# include <sys/socket.h>
# include <unistd.h>
# define INVALID_SOCKET (-1)
# define SOCKET_ERROR (-1)
namespace {
    const int send_recv_flag = MSG_NOSIGNAL;
}
#endif

using namespace std;

namespace boost {

    namespace network {

        talker::talker (net_base::family f) : _M_d(INVALID_SOCKET) {
            using namespace detail;
            _M_d = ::socket(translate_family(f), SOCK_STREAM, 0);
            if (_M_d == INVALID_SOCKET)
                throw net_error();
        }

        talker::talker (listener& l) : _M_d(INVALID_SOCKET) {
            _M_d = l.accept();
            if (_M_d == INVALID_SOCKET)
                throw net_error();
        }

        void
        talker::bind (sockaddr const* address, int length) {
            int r = ::bind(_M_d, address, length);
            if (r == SOCKET_ERROR)
                throw net_error();
        }

        void
        talker::connect (sockaddr const* address, int length) {
            int r = ::connect(_M_d, address, length);
            if (r == SOCKET_ERROR)
                throw net_error();
        }

        streamsize
        talker::read (char* s, streamsize n) {
            int r = ::recv(_M_d, s, n, send_recv_flag);

            if (r == SOCKET_ERROR)
#if defined(BOOST_WINDOWS)
                if (WSAGetLastError() == WSAEWOULDBLOCK)
#else
                if (errno == EWOULDBLOCK)
#endif
                    return 0;
                else
                    throw net_error();
            else if (r == 0)
                return -1;

            return r;
        }

        streamsize
        talker::write (char const* s, streamsize n) {
            int r = ::send(_M_d, s, n, send_recv_flag);

            if (r == SOCKET_ERROR)
#if defined(BOOST_WINDOWS)
                if (WSAGetLastError() == WSAEWOULDBLOCK)
#else
                if (errno == EWOULDBLOCK)
#endif
                    return 0;
                else
                    throw net_error();

            return r;
        }

        void
        talker::shutdown () {
            int r = ::shutdown(_M_d, SHUT_RDWR);
            if (r == SOCKET_ERROR)
                throw net_error();
        }

        int
        talker::peek () {
#if defined(BOOST_WINDOWS)
            unsigned long length = 0;
            int r = ::ioctlsocket(_M_d, FIONREAD, &length);
            if (r == SOCKET_ERROR)
                throw net_error();
            return static_cast<int>(length);
#else
            char buffer[BUFSIZ];
            int r = ::recv(_M_d, buffer, BUFSIZ, MSG_PEEK);
            if (r == SOCKET_ERROR)
                throw net_error();
            return r;
#endif
        }

    }

}

