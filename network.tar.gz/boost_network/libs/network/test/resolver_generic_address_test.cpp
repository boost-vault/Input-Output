// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <cassert>
#undef assert

#include <boost/network/resolver.hpp>
#include <boost/network/address.hpp>

using namespace std; // Don't fool yourself: calling std::assert doesn't compile
using namespace boost;
using namespace boost::network;

int main () {
  resolver r;
  r.resolve("localhost", "http");
  resolver::result_type::const_iterator i = r.result().begin();
  resolver::result_type::const_iterator j;
  for (j = i; j != r.result().end(); ++j)
    continue;
  assert(j == r.result().end());
  assert(i == r.result().begin());

  generic_address one(*i);
  generic_address two;
  two = *i;
  generic_address three(one);
  generic_address four;
  four = two;

  return 0;
}

