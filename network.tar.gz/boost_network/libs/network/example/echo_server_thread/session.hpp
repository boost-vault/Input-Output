// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(ECHO_SESSION_HPP)
#define ECHO_SESSION_HPP

#include <boost/shared_ptr.hpp>
#include <boost/network.hpp>

namespace echo {

    class session {
    public:

        typedef void result_type;

        session (boost::network::listener& l)
        : _M_conn(new boost::network::netstream(l)) {}

        void operator() () {
            char c;
            while (_M_conn->get(c)) {
                _M_conn->put(c).flush();
            }

            (*_M_conn)->shutdown();
        }

    private:
        boost::shared_ptr<boost::network::netstream> _M_conn;
    };

}

#endif // ECHO_SESSION_HPP
