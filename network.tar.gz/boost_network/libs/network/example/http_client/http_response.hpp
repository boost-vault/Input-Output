// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(HTTP_RESPONSE_HPP)
#define HTTP_RESPONSE_HPP

#include <iosfwd>
#include <map>
#include <string>

class http_response {
public:

    typedef std::map<std::string, std::string> fields_t;

    std::string const& response () const { return _M_response; }

    void response (std::string const& s) { _M_response = s; }

    fields_t const& fields () const { return _M_fields; }

    fields_t& fields () { return _M_fields; }

    void clear () {
        _M_response.clear();
        _M_fields.clear();
    }

private:
    std::string   _M_response;
    fields_t      _M_fields;
};

template <typename CharT, typename TraitsT>
std::basic_istream<CharT, TraitsT>&
operator>> (std::basic_istream<CharT, TraitsT>& i, http_response& m)
{
  m.clear();

  std::string s;
  std::getline(i, s);
  m.response(s);

  for (std::getline(i, s); s != "\r"; std::getline(i, s)) {
    std::string::size_type n = s.find(':');
    if (n != std::string::npos) {
        std::string key = s.substr(0, n);
        while (s[++n] == ' ')
            continue;
        m.fields()[key] = s.substr(n);
    } else {
        m.fields()["?"] = s;
    }
  }

  return i;
}

#endif // HTTP_RESPONSE_HPP

