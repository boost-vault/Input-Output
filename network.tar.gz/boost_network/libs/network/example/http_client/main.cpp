// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_ALL_NO_LIB

#include <algorithm>
#include <iostream>
#include <sstream>

#include <boost/network.hpp>
#include <boost/program_options.hpp>

#include <http_response.hpp>
#include <uri.hpp>

using namespace std;
using namespace boost;
using namespace boost::network;
using internet::uri;

class family_is {
public:
    family_is (net_base::family f) : _M_family(f) {}
    bool operator() (resolver::result_type::value_type const& v) const {
        return v.family() == _M_family;
    }
private:
    net_base::family _M_family;
};

int main (int argc, char* argv[])
{
    try
    {
        ios_base::sync_with_stdio(false);

        namespace po = boost::program_options;

        po::options_description o("Available options");
        o.add_options()
            ("help", "this help message")
            ("uri", po::value<string>(), "uri to obtain")
            ;

        po::positional_options_description p;
        p.add("uri",-1);

        po::variables_map vm;
        po::store(po::command_line_parser(argc, argv).
                      options(o).positional(p).run(), vm);
        po::notify(vm);    

        if (vm.count("help") || vm.count("uri") == 0) {
            cout << o << endl;
        }

        uri u;
        string const& tmp = vm["uri"].as<string>();
        u.parse(tmp.begin(), tmp.end());
        if (u.schema() != "http") {
            cout << "The only supported schema is http" << endl;
            return 1;
        }

        string server = u.authority(); // FIXME: userinfo?
        string path = u.path();

        resolver r(server, "http");
        resolver::result_type::const_iterator i =
            find_if(r.result().begin(),
                    r.result().end(),
                    family_is(net_base::ipv4));

        netstream stream(i->family());
        stream->connect(*i);

        stream << "GET " << path << " HTTP/1.1\r\n"
               << "Host: " << server << "\r\n"
               << "\r\n" << std::flush;

        http_response resp;
        stream >> resp;

        std::streamsize size = -1;

        http_response::fields_t::const_iterator j =
            resp.fields().find("Content-Lentgh");
        if (j != resp.fields().end()) {
            size = std::atoi(j->second.c_str());
        }

        // How do we preallocate size bytes?
        if (size != 0)
            cout << stream.rdbuf();

    } catch (exception const& e) {
        cout << e.what() << endl;
    }

    return 0;
}
