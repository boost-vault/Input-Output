// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(QOTD_SESSION_HPP)
#define QOTD_SESSION_HPP

#include <boost/shared_ptr.hpp>
#include <boost/network.hpp>

namespace qotd {

    class session {
    public:

        typedef void result_type;

        session (boost::network::listener& l)
        : _M_conn(new boost::network::netstream(l)) {}

        void operator() () {
            *_M_conn << "The Matrix is everywhere. It is all around us.\r\n"
                     << std::flush;
            (*_M_conn)->shutdown();
        }

    private:
        boost::shared_ptr<boost::network::netstream> _M_conn;
    };

}

#endif // QOTD_SESSION_HPP
