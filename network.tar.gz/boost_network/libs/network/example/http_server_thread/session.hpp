// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(HTTP_SESSION_HPP)
#define HTTP_SESSION_HPP

#include <boost/shared_ptr.hpp>
#include <boost/network.hpp>

namespace http {

    class session {
    public:

        typedef void result_type;

        session (boost::network::listener& l)
        : _M_conn(new boost::network::netstream(l)) {}

        void operator() ();

    private:
        boost::shared_ptr<boost::network::netstream> _M_conn;
    };

}

#endif // HTTP_SESSION_HPP
