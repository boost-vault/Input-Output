// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(INTERNET_URI_HPP)
#define INTERNET_URI_HPP

#include <iosfwd>
#include <string>

#include <boost/spirit.hpp>

#include <abnf.hpp>

namespace internet {

    class uri {
    public:

        std::string const& schema () const { return _M_schema; }

        void schema (std::string const& s) { _M_schema = s; }

        std::string const& authority () const { return _M_authority; }

        void authority (std::string const& s) { _M_authority = s; };

        std::string const& path () const { return _M_path; }

        void path (std::string const& s) { _M_path = s; };

        std::string const& query () const { return _M_query; }

        void query (std::string const& s) { _M_query = s; }

        std::string const& fragment () const { return _M_fragment; }

        void fragment (std::string const& s) { _M_fragment = s; }

        void
        clear () {
            _M_schema.clear();
            _M_authority.clear();
            _M_path.clear();
            _M_query.clear();
            _M_fragment.clear();
        }

        template <typename IteratorT>
        boost::spirit::parse_info<IteratorT>
        parse (IteratorT begin, IteratorT end);

    private:
        std::string   _M_schema;
        std::string   _M_authority;
        std::string   _M_path;
        std::string   _M_query;
        std::string   _M_fragment;
    };

    template <typename CharT, typename TraitsT>
    std::basic_ostream<CharT, TraitsT>&
    operator<< (std::basic_ostream<CharT, TraitsT>& o, uri const& m) {

        o << m.schema() << ':';

        if (!m.authority().empty())
            o << "//" << m.authority();

        if (!m.path().empty())
            o << m.path();

        if (!m.query().empty())
            o << '?' << m.query();

        if (!m.fragment().empty())
            o << '#' << m.fragment();

        return o;
    }

    template <typename CharT, typename TraitsT>
    std::basic_istream<CharT, TraitsT>&
    operator>> (std::basic_istream<CharT, TraitsT>& i, uri& m) {
        using namespace boost::spirit;

        typedef multi_pass<std::istreambuf_iterator<char> > iterator_t;
        iterator_t begin(i);
        iterator_t end = make_multi_pass(std::istreambuf_iterator<char>());

        parse_info<iterator_t> info = m.parse(begin, end);
        if (!info.hit)
            i.setstate(std::ios_base::failbit);

        return i;
    }

    namespace detail
    {
        using namespace boost::spirit;
        using namespace phoenix;

        class assign_schema_action {
        public:

            template <typename T, typename ValueT>
            void act (T& ref, ValueT const& value) const {
                ref.schema(value);
            }

            template <typename T, typename IteratorT>
            void act (T& ref, IteratorT const& first,
                      IteratorT const& last) const {
                typedef std::string value_type;
                value_type vt(first, last);
                ref.schema(vt);
            }

        };

        template <typename T>
        inline ref_value_actor<T, assign_schema_action>
        assign_schema_a (T& ref) {
            return ref_value_actor<T, assign_schema_action>(ref);
        }

        class assign_authority_action {
        public:

            template <typename T, typename ValueT>
            void act (T& ref, ValueT const& value) const {
                ref.authority(value);
            }

            template <typename T, typename IteratorT>
            void act (T& ref, IteratorT const& first,
                      IteratorT const& last) const {
                typedef std::string value_type;
                value_type vt(first, last);
                ref.authority(vt);
            }

        };

        template <typename T>
        inline ref_value_actor<T, assign_authority_action>
        assign_authority_a (T& ref) {
            return ref_value_actor<T, assign_authority_action>(ref);
        }

        class assign_path_action {
        public:

            template <typename T, typename ValueT>
            void act (T& ref, ValueT const& value) const {
                ref.path(value);
            }

            template <typename T, typename IteratorT>
            void act (T& ref, IteratorT const& first,
                      IteratorT const& last) const {
                typedef std::string value_type;
                value_type vt(first, last);
                ref.path(vt);
            }

        };

        template <typename T>
        inline ref_value_actor<T, assign_path_action>
        assign_path_a (T& ref) {
            return ref_value_actor<T, assign_path_action>(ref);
        }

        class assign_query_action {
        public:

            template <typename T, typename ValueT>
            void act (T& ref, ValueT const& value) const {
                ref.query(value);
            }

            template <typename T, typename IteratorT>
            void act (T& ref, IteratorT const& first,
                      IteratorT const& last) const {
                typedef std::string value_type;
                value_type vt(first, last);
                ref.query(vt);
            }

        };

        template <typename T>
        inline ref_value_actor<T, assign_query_action>
        assign_query_a (T& ref) {
            return ref_value_actor<T, assign_query_action>(ref);
        }

        class assign_fragment_action {
        public:

            template <typename T, typename ValueT>
            void act (T& ref, ValueT const& value) const {
                ref.fragment(value);
            }

            template <typename T, typename IteratorT>
            void act (T& ref, IteratorT const& first,
                      IteratorT const& last) const {
                typedef std::string value_type;
                value_type vt(first, last);
                ref.fragment(vt);
            }

        };

        template <typename T>
        inline ref_value_actor<T, assign_fragment_action>
        assign_fragment_a (T& ref) {
            return ref_value_actor<T, assign_fragment_action>(ref);
        }

        class grammar : public boost::spirit::grammar<grammar> {
        public:

            grammar (uri& u) : _M_uri(u) {}

            template <typename ScannerT>
            class definition : public internet::abnf<ScannerT> {
            public:

                typedef rule<ScannerT> rule_t;

                definition (grammar const& self) {
                    uri = schema[ assign_schema_a(self._M_uri) ] >> ':'
                        >> hier_part
                        >> !('?' >> query[ assign_query_a(self._M_uri) ])
                        >> !('#' >> fragment[ assign_fragment_a(self._M_uri) ]);
                    hier_part = ("//"
                                >> authority[ assign_authority_a(self._M_uri) ]
                                >> path_abempty[ assign_path_a(self._M_uri) ])
                                || path_absolute[ assign_path_a(self._M_uri) ]
                                || path_rootless[ assign_path_a(self._M_uri) ]
                                || path_empty;

                    schema = ALPHA >> *(ALPHA || DIGIT || '+' || '-' || '.');

                    authority = !(userinfo >> '@') >> host >> !(':' >> port);
                    userinfo = *(unreserved || pct_encoded || sub_delims || ':');
                    host = IP_literal || IPv4address || reg_name;
                    IP_literal = ch_p('[') >> ( IPv6address || IPvFuture ) >> ']';
                    IPvFuture = 'v' >> +HEXDIG >> '.' >> +(unreserved || sub_delims || ':');
                    IPv6address =                                                     (repeat_p(6)[ h16 >> ':' ] >> ls32)
                                ||                                            ("::" >> repeat_p(5)[ h16 >> ':' ] >> ls32)
                                ||                                (!( h16 ) >> "::" >> repeat_p(4)[ h16 >> ':' ] >> ls32)
                                || (!( repeat_p(0,1)[ h16 >> ':' ] >> h16 ) >> "::" >> repeat_p(3)[ h16 >> ':' ] >> ls32)
                                || (!( repeat_p(0,2)[ h16 >> ':' ] >> h16 ) >> "::" >> repeat_p(2)[ h16 >> ':' ] >> ls32)
                                || (!( repeat_p(0,3)[ h16 >> ':' ] >> h16 ) >> "::" >>              h16 >> ':'   >> ls32)
                                || (!( repeat_p(0,4)[ h16 >> ':' ] >> h16 ) >> "::" >>                              ls32)
                                || (!( repeat_p(0,5)[ h16 >> ':' ] >> h16 ) >> "::" >>                              h16)
                                || (!( repeat_p(0,6)[ h16 >> ':' ] >> h16 ) >> "::");
                    ls32 = ( h16 >> ':' >> h16 ) || IPv4address;
                    h16 = repeat_p(1,4)[ HEXDIG ];
                    IPv4address = dec_octet >> '.' >> dec_octet >> '.' >> dec_octet
                                >> '.' >> dec_octet;
                    dec_octet = DIGIT
                                || (range_p(char(0x31), char(0x39)) >> DIGIT)
                                || ('1' >> DIGIT >> DIGIT)
                                || ('2' >> range_p(char(0x30), char(0x34)) >> DIGIT)
                                || ("25" >> range_p(char(0x30), char(0x35)));
                    reg_name = *(unreserved || pct_encoded || sub_delims);
                    port = *DIGIT;

                    path_abempty = *('/' >> segment);
                    path_absolute = '/' >> !(segment_nz >> *('/' >> segment));
                    path_rootless = segment_nz >> *('/' >> segment);
                    path_empty = epsilon_p;

                    segment = *pchar;
                    segment_nz = +pchar;
                    pchar = unreserved || pct_encoded || sub_delims || ':' || '@';

                    query = *(pchar >> '/' >> '?');

                    fragment = *(pchar >> '/' >> '?');

                    pct_encoded = '%' >> HEXDIG >> HEXDIG;
                    sub_delims = ch_p('!') || '$' || '&' || '\'' || '(' || ')'
                                           || '*' || '+' || ',' || ';' || '=';
                    unreserved = ALPHA || DIGIT || '-' || '.' || '_' || '~';
                }

                rule_t const& start () const { return uri; }

            protected:
                using internet::abnf<ScannerT>::ALPHA;
                using internet::abnf<ScannerT>::DIGIT;
                using internet::abnf<ScannerT>::HEXDIG;

            private:
                rule_t uri;
                rule_t schema;
                rule_t hier_part;
                rule_t query;
                rule_t fragment;

                rule_t authority;
                rule_t userinfo;
                rule_t host;
                rule_t IP_literal;
                rule_t IPvFuture;
                rule_t IPv6address;
                rule_t ls32;
                rule_t h16;
                rule_t IPv4address;
                rule_t dec_octet;
                rule_t reg_name;
                rule_t port;

                rule_t path_abempty;
                rule_t path_absolute;
                rule_t path_rootless;
                rule_t path_empty;

                rule_t segment;
                rule_t segment_nz;
                rule_t pchar;

                rule_t pct_encoded;
                rule_t sub_delims;
                rule_t unreserved;
            };

        private:
            uri mutable& _M_uri;
        };
    }

    template <typename IteratorT>
    boost::spirit::parse_info<IteratorT>
    uri::parse (IteratorT begin, IteratorT end) {
        this->clear();
        detail::grammar g(*this);
        return boost::spirit::parse(begin, end, g);
    }

}

#endif // INTERNET_URI_HPP

