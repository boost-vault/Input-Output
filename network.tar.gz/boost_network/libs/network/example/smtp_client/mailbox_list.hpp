// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(INTERNET_MAILBOX_LIST_HPP)
#define INTERNET_MAILBOX_LIST_HPP

#include <list>
#include <string>

#include <boost/spirit.hpp>

#include <mailbox.hpp>
#include <abnf.hpp>

namespace internet {

    class mailbox_list {
    public:
    
        typedef std::list<mailbox> list_type;

        list_type const& list () const { return _M_list; }

        list_type& list () { return _M_list; }

        void clear () {
            _M_list.clear();
        }

        template <typename IteratorT>
        boost::spirit::parse_info<IteratorT>
        parse (IteratorT const& begin, IteratorT const& end);

    private:
        list_type _M_list;
    };

    namespace detail {

        using namespace boost::spirit;
        using namespace phoenix;

        class push_back_mailbox_a {
        public:
            push_back_mailbox_a (mailbox_list& mbl) : ref(mbl) {}
            template <typename IteratorT>
            void operator() (IteratorT const& first,
                             IteratorT const& last) const {
                mailbox mb;
                mb.parse(first, last);
                ref.push_back(mb);
            }
        private:
            mailbox_list& ref;
        };

        class mailbox_list_grammar : public boost::spirit::grammar<mailbox_grammar> {
        public:

            mailbox_list_grammar (mailbox_list& mbl) : _M_mbl(mbl) {}

            template <typename ScannerT>
            class definition : public internet::abnf<ScannerT> {
            public:

                typedef rule<ScannerT> rule_t;

                definition (mailbox_list_grammar const& self) {
                }

                rule_t const& start () const { return mailbox_list; }

            private:
                rule_t mailbox_list;
            };

        private:
            mailbox_list mutable& _M_mbl;
        };

    }

    template <typename IteratorT>
    boost::spirit::parse_info<IteratorT>
    mailbox_list::parse (IteratorT const& begin, IteratorT const& end) {
        using namespace boost::spirit;
        this->clear();
        detail::mailbox_list_grammar grammar(*this);
        parse_info<IteratorT> info = boost::spirit::parse(begin, end, grammar);
        return info;
    }

}

#endif // INTERNET_MAILBOX_LIST_HPP

