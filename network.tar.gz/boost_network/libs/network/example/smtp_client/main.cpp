// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <algorithm>
#include <exception>
#include <fstream>
#include <iostream>
#include <sstream>

#include <boost/network.hpp>
#include <boost/program_options.hpp>

#include <message.hpp>
#include <mailbox.hpp>
#include <smtp_transaction.hpp>

using namespace std;
namespace po = boost::program_options;
namespace net = boost::network;
using namespace internet;

class field_name_is {
public:

    field_name_is (std::string const& s) : _M_name(s) {}

    bool operator() (std::pair<std::string, std::string> const& p) {
        return p.first == _M_name;
    }
private:
    std::string _M_name;
};

bool validate (message const& m) {
    typedef message::header_type::const_iterator const_iterator;

    const_iterator date = find_if(m.header().begin(), m.header().end(), field_name_is("Date"));
    if (date == m.header().end())
        return false;

    const_iterator from = find_if(m.header().begin(), m.header().end(), field_name_is("From"));
    if (from == m.header().end())
        return false;
        
    // Parse from; determine is_multi_address_from
    bool is_multi_address_from = false;

    if (is_multi_address_from) {
        const_iterator sender = find_if(m.header().begin(), m.header().end(), field_name_is("Sender"));
        if (sender == m.header().end())
            return false;
    }

    return true;
}

int main(int argc, char* argv[])
{
    try {
        po::options_description o("Allowed options");
        o.add_options()
            ("help,h", "produce this help message")
            ("host,H", po::value<string>(), "Host of server to deliver to")
            ("port,P", po::value<string>(), "Port on server")
            ("file,F", po::value<string>(), "File containing message to send")
            ;

        po::variables_map vm;
        po::store(po::parse_command_line(argc, argv, o), vm);
        po::notify(vm);

        if (vm.count("help") > 0 || vm.count("file") != 1) {
            cout << o << endl;
            return 1;
        }

        ifstream in(vm["file"].as<string>().c_str(), ios_base::binary);
        message m;
        in >> m;
        if (!in) {
            cout << "Failed to parse internet::message..." << endl;
            return 1;
        }
        if (!validate(m)) {
            cout << "Message header does not validate..." << endl;
            return 1;
        }

        smtp_transaction t;

        t.identity("localhost");

        typedef message::header_type::const_iterator const_iterator;
        
        /**
         * Finding MAIL FROM.
         */
         
        const_iterator return_path = find_if(m.header().begin(),
                                             m.header().end(),
                                             field_name_is("Sender"));
        if (return_path == m.header().end()) {
            return_path = find_if(m.header().begin(), m.header().end(),
                                  field_name_is("From"));
        }
        string const& rp_body = return_path->second;
        mailbox from;
        bool parsed = from.parse(rp_body.begin(), rp_body.end()).hit;
        if (!parsed) {
            cout << "Couldn't parse return-path mailbox..." << endl;
            return 1;
        }

        /**
         * Finding RCPT TO. FIXME: should be parsing mailbox-list.
         */

        const_iterator rcpt_it = find_if(m.header().begin(),
                                             m.header().end(),
                                             field_name_is("To"));
        string const& rcpt_body = rcpt_it->second;

        mailbox rcpt;
        parsed = rcpt.parse(rcpt_body.begin(), rcpt_body.end()).hit;
        if (!parsed) {
            cout << "Couldn't parse recipient mailbox..." << endl;
            return 1;
        }
        
        /**
         * Preparing SMTP transaction.
         */

        t.sender(from.addr_spec());
        t.recipient().push_back(rcpt.addr_spec());
        t.message(m);

        net::resolver r(vm.count("host") > 0 ? vm["host"].as<string>()
                                             : "localhost",
                        vm.count("port") > 0 ? vm["port"].as<string>()
                                             : "smtp"
                        );
        net::resolver::result_type::const_iterator i = r.result().begin();
        net::netstream s(i->family());
        s->connect(*i);
        
        s & t;
        if (!s) {
            cout << "Failed to process smtp transaction..." << endl;
        }

    } catch (net::net_error const& e) {
        cout << "Error code: " << e.code() << ": " << e.what() << endl;
        return 1;
    } catch (exception const& e) {
        cout << "Exception caught: " << e.what() << endl;
        return 1;
    }

	return 0;
}

