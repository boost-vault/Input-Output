// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(TIME_SESSION_H)
#define TIME_SESSION_H

#include <ctime>

#include <boost/shared_ptr.hpp>
#include <boost/network.hpp>

#define TIME_OFFSET 2208988800UL

namespace time_ {

    class session {
    public:

        typedef void result_type;

        session (boost::network::listener& l)
        : _M_conn(new boost::network::netstream(l)) {}

        void operator() () {
            char s[4];
            this->time(s);
            *_M_conn << s << std::flush;

            (*_M_conn)->shutdown();
        }

    private:

        void time (char* s) {
            std::time_t now = std::time(0);
            unsigned long i32 = static_cast<unsigned long>(now) + TIME_OFFSET;
            s[0] = i32 >> 24;
            s[1] = i32 >> 16;
            s[2] = i32 >> 8;
            s[3] = i32;
        }

        boost::shared_ptr<boost::network::netstream> _M_conn;
    };

}

#endif // TIME_SESSION_HPP
