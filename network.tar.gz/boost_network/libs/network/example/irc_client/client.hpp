// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(CLIENT_HPP)
#define CLIENT_HPP

#include <configuration.hpp>
#include <message.hpp>

#include <boost/signal.hpp>
#include <boost/network.hpp>

using namespace boost;
using namespace boost::network;

namespace irc {

    /**
     * @brief An IRC client.
     * 
     * irc::client is a model of AdaptableGenerator.
     * 
     * This class is meant as a functor proper for boost::thread.
     */
    class client {
    public:

        class proxy {
        public:

            proxy (client& c) : _M_client(c) {}
	
            proxy (proxy const& p) : _M_client(p._M_client) {}

            proxy& send (message const& m) {
                _M_client._M_connection << m;
                return *this;
            }

            proxy& flush () {
                _M_client._M_connection.flush();
                return *this;
            }

        private:
            client& _M_client;
        };

        client (configuration const& c);

        signal<void (message const&, proxy)>&
        signal () { return _M_signal; }

        typedef void result_type;

        void operator() ();

    private:
        configuration const& _M_configuration;
        // For some bizarre reason the full reference is required here.
        boost::signal<void (message const&, proxy)> _M_signal;
        netstream _M_connection;
    };

}

#endif // CLIENT_HPP
