// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef IRC_BOT_HPP
#define IRC_BOT_HPP

#include <client.hpp>

namespace irc {

    class bot {
    public:

    bot (configuration const& c);

    typedef void result_type;

    void operator() ();	

    private:
        client _M_client;
    };

}

#endif // IRC_BOT_HPP
