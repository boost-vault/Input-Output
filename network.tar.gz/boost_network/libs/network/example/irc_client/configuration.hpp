// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(CONFIGURATION_HPP)
#define CONFIGURATION_HPP

#include <list>
#include <string>

namespace irc {

    class configuration {
    public:

        configuration ();

        std::list<std::string> const&
        servers () const { return _M_servers; }

        std::list<std::string>&
        servers () { return _M_servers; }

        std::string const&
        nickname () const { return _M_nickname; }

        void
        nickname (std::string const& s) { _M_nickname = s; }

        std::string const&
        username () const { return _M_username; }

        void
        username (std::string const& s) { _M_username = s; }

        short unsigned int
        mode () const { return _M_mode; }

        void
        mode (short unsigned int i) { _M_mode = i; }

        std::string const&
        realname () const { return _M_realname; }

        void
        realname (std::string const& s) { _M_realname = s; }

        std::list<std::string> const&
        channels () const { return _M_channels; }

        std::list<std::string>&
        channels () { return _M_channels; }

        std::string const&
        password () const { return _M_password; }

        void
        password (std::string const& s) { _M_password = s; }

    private:
        std::list<std::string> _M_servers;
        std::string _M_nickname;
        std::string _M_username;
        short unsigned int _M_mode;
        std::string _M_realname;
        std::list<std::string> _M_channels;
        std::string _M_password;
    };

}

#endif // CONFIGURATION_HPP
