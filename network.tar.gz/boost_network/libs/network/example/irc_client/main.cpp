// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_ALL_NO_LIB

#include <exception>
#include <iostream>

#include <bot.hpp>

using namespace std;

int main (int argc, char const* argv[]) {
    try {
        ios_base::sync_with_stdio(false);

        if (argc < 3) {
            cout << "usage: irc_bot servername nickname channel" << endl;
            return 1;
        }

        irc::configuration c;
        c.servers().clear(); // Clear default; should remove that there.
        c.servers().push_back(argv[1]);
        c.nickname(argv[2]);
        c.channels().clear(); // Clear default; should remove that there.
        c.channels().push_back(argv[3]);

        irc::bot b(c);
        b();

    } catch (std::exception const& e) {
        cout << e.what() << endl;
        return 1;
    } catch (...) {
        cout << "Exception caught." << endl;
        return 1;
    }
    return 0;
}

