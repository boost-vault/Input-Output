// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(DISCARD_SESSION_H)
#define DISCARD_SESSION_H

#include <boost/shared_ptr.hpp>
#include <boost/network.hpp>

namespace discard {

    class session {
    public:

        typedef void result_type;

        session (boost::network::listener& l)
        : _M_conn(new boost::network::netstream(l)) {}

        void operator() () {
            while (_M_conn->ignore());

            (*_M_conn)->shutdown();
        }

    private:
        boost::shared_ptr<boost::network::netstream> _M_conn;
    };

}

#endif // DISCARD_SESSION_HPP
