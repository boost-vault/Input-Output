// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(BOOST_NETWORK_NET_HPP)
#define BOOST_NETWORK_NET_HPP

#include <boost/network/detail/config.hpp>

namespace boost {

    namespace network {

        namespace detail {

            enum _Family {

                _S_af_invalid    = 1L << 0,
                _S_af_local      = 1L << 1,
                _S_af_ipv4       = 1L << 2,
                _S_af_ipv6       = 1L << 3,
                _S_af_end = 1L << 4

            };

        }

        class BOOST_NETWORK_DLL_INTERFACE net_base {
        public:

#if defined(BOOST_WINDOWS)
            typedef unsigned int descriptor_type;
#else
            typedef int          descriptor_type;
#endif

            typedef detail::_Family family;

            static const family ipv4 = family(detail::_S_af_ipv4);
            static const family ipv6 = family(detail::_S_af_ipv6);

        };

    }

}

#endif // BOOST_NETWORK_NET_HPP

