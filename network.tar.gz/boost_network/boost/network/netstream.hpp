// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(BOOST_NETWORK_NETSTREAM_HPP)
#define BOOST_NETWORK_NETSTREAM_HPP

#include <boost/network/detail/config.hpp>

#include <cassert>
#include <cstdio>
#include <istream>
#include <ostream>

#include <boost/iostreams/stream.hpp>
#include <boost/network/net.hpp>
#include <boost/network/talker.hpp>

namespace boost {

    namespace network {

        typedef boost::iostreams::stream_buffer<talker> netbuf;
        typedef boost::iostreams::stream<talker>        netstream;

    }

}

#endif // BOOST_NETWORK_NETSTREAM_HPP

