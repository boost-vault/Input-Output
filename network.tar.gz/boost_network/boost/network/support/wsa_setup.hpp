// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(BOOST_NETWORK_WSA_SETUP_HPP)
#define BOOST_NETWORK_WSA_SETUP_HPP

#include <boost/network/detail/config.hpp>

#include <memory>

struct WSAData;

namespace boost {

    namespace network {

        class wsa_setup {
        public:

            wsa_setup ();

            ~wsa_setup () throw ();

        private:
            std::auto_ptr<WSAData> _M_wsaData;
        };

    }

}

#endif // BOOST_NETWORK_WSA_SETUP_HPP

