// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(BOOST_NETWORK_DETAIL_HPP)
#define BOOST_NETWORK_DETAIL_HPP

#include <boost/network/detail/config.hpp>
#include <boost/network/net.hpp>

namespace boost {

    namespace network {

        namespace detail {

            BOOST_NETWORK_DLL_PRIVATE
            int
            translate_family (net_base::family f);

            BOOST_NETWORK_DLL_PRIVATE
            net_base::family
            translate_family (int f);

        }

    }

}

#endif // BOOST_NETWORK_DETAIL_HPP

