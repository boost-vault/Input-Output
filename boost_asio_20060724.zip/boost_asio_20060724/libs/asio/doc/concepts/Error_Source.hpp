//
// Error_Source.hpp
// ~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2006 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

/// Error source concept.
/**
 * @par Implemented By:
 * boost::asio::basic_deadline_timer @n
 * boost::asio::basic_datagram_socket @n
 * boost::asio::basic_locking_dispatcher @n
 * boost::asio::basic_socket_acceptor @n
 * boost::asio::basic_stream_socket @n
 * boost::asio::buffered_read_stream @n
 * boost::asio::buffered_write_stream @n
 * boost::asio::buffered_stream @n
 * boost::asio::ipv4::basic_host_resolver @n
 * boost::asio::ssl::stream
 */
class Error_Source
{
public:
  /// The type used for reporting errors.
  typedef implementation_defined error_type;
};
