#include <boost/iostreams/utility/indent_scoped_ostreambuf.hpp>
#include <iostream>

int main(void)
{
; std::ostream& mout=std::cout
; mout<<"line1\n"
;
; {
  ; boost::iostreams::indent_scoped_ostreambuf<char> indent_outbuf(std::cout,4)
  ; ++mout
  ; mout<<"line1.1"<<std::endl
  ; ++mout
  ; mout<<"line1.1.1"<<std::endl
  #if 1
  ; mout<<"line1.1.2"<<std::endl
  #endif
  ; --mout
  ; unsigned u=22
  ; mout<<"line1.2:unsigned="<<u<<std::endl
  ; float f=3.1416
  ; mout<<"line1.3:float="<<f<<std::endl
  ; --mout
  ; --mout
  ; mout<<"line2\n"
  ; ++mout
  ; mout<<"line3\n"
  ;}
; mout<<"line4\n"
; return 0
;}
//Expected output:
/*
line1
    line1.1
        line1.1.1
        line1.1.2
    line1.2:unsigned=22
    line1.3:float=3.1416
line2
    line3
line4
 */

