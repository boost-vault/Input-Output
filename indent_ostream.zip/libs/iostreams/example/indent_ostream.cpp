#include <iostream>
#include <boost/iostreams/utility/indent_ostream.hpp>

void test_conversion(std::ostream& sout)
{
    sout<<"inside test_conversion:(std::ostream& sout)\n";
    get_sink(sout)<<"inside test_conversion:get_sink(sout)\n";
}    

int main(void)
{
; typedef boost::iostreams::indent_ostream<> ostrm_type;
; ostrm_type mout(std::cout,2)
; mout<<"line1\n"
; ++mout
; mout<<"line1.1"<<std::endl
; mout<<indent_in<<"line1.1.1"<<std::endl
; test_conversion(mout)
#if 1
; mout.get_sink()<<"mout.get_sink()\n";
; get_sink(mout)<<"get_sink(mout)\n";
; mout<<"line1.1.2"<<std::endl
#endif
; indent_out(mout)
; unsigned u=22
; mout<<"line1.2:unsigned="<<u<<std::endl
; float f=3.1416
; mout<<"line1.3:float="<<f<<std::endl
; --mout
; --mout
; mout<<"line2\n"
; return 0
;
}
//Expected output:
/*
line1
  line1.1
    line1.1.1
    inside test_conversion:(std::ostream& sout)
inside test_conversion:get_sink(sout)
mout.get_sink()
get_sink(mout)
    line1.1.2
  line1.2:unsigned=22
  line1.3:float=3.1416
line2
 */

