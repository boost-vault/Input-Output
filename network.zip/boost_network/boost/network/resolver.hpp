// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(BOOST_NETWORK_RESOLVER_HPP)
#define BOOST_NETWORK_RESOLVER_HPP

#include <boost/network/detail/config.hpp>
#include <boost/network/net.hpp>

#include <algorithm>
#include <iterator>
#include <string>

namespace boost {

    namespace network {

        /**
         * Forward declaration for the sake of
         * resolver_result_container's friendship.
         */
        class resolver;

        /**
         * Model of NetworkAddress.
         */
        class BOOST_NETWORK_DLL_INTERFACE resolved_address {
        public:

            resolved_address (addrinfo const* a) : _M_a(a) {}

            ~resolved_address () {}

            net_base::family
            family () const;

            sockaddr const*
            address () const;

            int
            length () const;

            bool
            operator== (resolved_address const& that) const {
                return _M_a == that._M_a;
            }

            bool
            operator< (resolved_address const& that) const {
                return _M_a < that._M_a; // FIXME!
            }

            friend class resolver_result_iterator;

        protected:

            BOOST_NETWORK_DLL_PRIVATE
            resolved_address (resolved_address const& that)
            : _M_a(that._M_a) {}

            BOOST_NETWORK_DLL_PRIVATE
            addrinfo const*
            handle () const { return _M_a; }

        private:
            addrinfo const* _M_a;
        };

        // namespace detail {

        /**
         * This type is a model of ForwardIterator.
         *
         * This iterator is never mutable.
         */
        class BOOST_NETWORK_DLL_INTERFACE resolver_result_iterator
        : public std::iterator<std::forward_iterator_tag, resolved_address> {
        public:

            resolver_result_iterator () : _M_r(0) {}

            resolver_result_iterator (resolver_result_iterator const& that)
            : _M_r(that._M_r) {}

            resolver_result_iterator&
            operator= (resolver_result_iterator const& that) {
                _M_r = that._M_r;
                return *this;
            }

            value_type const&
            operator* () const {
                return _M_r;
            }

            value_type const*
            operator-> () const {
                return &_M_r;
            }

            bool
            operator== (resolver_result_iterator const& that) const {
                return _M_r == that._M_r;
            }

            bool
            operator!= (resolver_result_iterator const& that) const{
                return !(*this == that);
            }

            resolver_result_iterator&
            operator++ ();

            resolver_result_iterator
            operator++ (int) {
                resolver_result_iterator tmp(*this);
                ++(*this);
                return tmp;
            }

            friend class resolver_result_container;

        protected:

            BOOST_NETWORK_DLL_PRIVATE
            resolver_result_iterator (addrinfo const* a) : _M_r(a) {}

        private:
            value_type _M_r;
        };

        /**
         * This type is a model of ForwardContainer.
         *
         * This container offers no mutable iterators, and has constant size.
         */
        class BOOST_NETWORK_DLL_INTERFACE resolver_result_container {
        public:

            typedef resolved_address         value_type;
            typedef resolver_result_iterator iterator;
            typedef resolver_result_iterator const_iterator;
            typedef value_type&              reference;
            typedef value_type const&        const_reference;
            typedef value_type*              pointer;
            typedef size_t                   difference_type;
            typedef size_t                   size_type;

            resolver_result_container () : _M_a(0) {}

            /**
             * Copy constructor.
             *
             * This constructor must never be called.
             * If this container is copied, we'll get a double free.
             * This container is a non-conforming ForwardContainer. :)
             *
             * This will be solved when a proper resource wrapper is chosen
             * to keep the result of getaddrinfo inside class resolver.
             */
#if 0
            resolver_result_container (resolver_result_container const& that)
            : _M_a(that._M_a) {}
#endif

            ~resolver_result_container ();

            /**
             * Assignment operator.
             *
             * This operator must never be called.
             * If this container is copied, we'll get a double free.
             * This container is a non-conforming ForwardContainer. :)
             *
             * This will be solved when a proper resource wrapper is chosen
             * to keep the result of getaddrinfo inside class resolver.
             */
#if 0
            resolver_result_container&
            operator= (resolver_result_container const& that) {
                _M_a = that._M_a;
                return *this;
            }
#endif

            bool
            operator== (resolver_result_container const& that) {
                if (this->size() != that.size())
                    return false;

                iterator i = this->begin();
                iterator j = that.begin();
                while ((i != this->end()) && (j != that.end()))
                    if (i++ != j++)
                        return false;

                return true;
            }

            bool
            operator!= (resolver_result_container const& that) {
                return !(*this == that);
            }

            bool
            operator< (resolver_result_container const& that) const {
                return std::lexicographical_compare(this->begin(),
                                                    this->end(),
                                                    that.begin(),
                                                    that.end());
            }

            bool
            operator> (resolver_result_container const& that) const {
                return that < *this;
            }

            bool
            operator<= (resolver_result_container const& that) const {
                return !(that < *this);
            }

            bool
            operator>= (resolver_result_container const& that) const {
                return !(*this < that);
            }

            const_iterator
            begin () const {
                return resolver_result_iterator(_M_a);
            }

            const_iterator
            end () const {
                return resolver_result_iterator();
            }

            size_type
            size () const;

            size_type
            max_size () const {
                return size();
            }

            bool
            empty () const {
                return _M_a ? false : true;
            }

            void
            swap (resolver_result_container& that) {
                std::swap(_M_a, that._M_a);
            }

            friend class resolver;

        protected:

            BOOST_NETWORK_DLL_PRIVATE
            resolver_result_container (addrinfo* a) : _M_a(a) {}

        private:
            addrinfo* _M_a;
        };
        
        // } // namespace detail

        class BOOST_NETWORK_DLL_INTERFACE resolver {
        public:

            typedef resolver_result_container result_type;

            resolver () : _M_result() {}
            
            resolver (std::string const& host, std::string const& service)
            : _M_result() {
                this->resolve(host, service);
            }                

            ~resolver () {}

            void resolve (std::string const& host, std::string const& service);

            result_type const& result () const { return _M_result; }

        private:
            result_type _M_result;
        };

    }

}

#endif // BOOST_NETWORK_RESOLVER_HPP

