// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(BOOST_NETWORK_SOCKET_ERROR_HPP)
#define BOOST_NETWORK_SOCKET_ERROR_HPP

#include <boost/network/detail/config.hpp>

#include <stdexcept>

namespace boost {

    namespace network {

        class BOOST_NETWORK_DLL_INTERFACE net_error
        : public std::runtime_error {
        public:

            net_error ();

            virtual ~net_error () throw () {}

            virtual int code () const throw () { return _M_code; }

        private:
            int _M_code;
        };

    }

}

#endif // BOOST_NETWORK_SOCKET_ERROR_HPP

