// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(BOOST_NETWORK_DETAIL_CONFIG_HPP)
#define BOOST_NETWORK_DETAIL_CONFIG_HPP

#include <boost/config.hpp>

#if defined(BOOST_NETWORK_DLL_BUILDING)
  #if defined(_MSC_VER) && defined(_MT)
   #if defined(BOOST_NETWORK_DLL_BUILDING)
      #define BOOST_NETWORK_DLL_INTERFACE __declspec(dllexport)
    #else
      #define BOOST_NETWORK_DLL_INTERFACE __declspec(dllimport)
    #endif
  #elif __GNUC__ > 4 || \
    (__GNUC__ == 4 && (__GNUC_MINOR__ > 0 || \
                        (__GNUC_MINOR__ == 0 && __GNUC_PATCHLEVEL__ >= 2)))
    #define BOOST_NETWORK_DLL_INTERFACE __attribute__((visibility("default")))
    #define BOOST_NETWORK_DLL_PRIVATE   __attribute__((visibility("hidden")))
    #pragma GCC visibility push(hidden)
  #endif
#endif

#if !defined(BOOST_NETWORK_DLL_INTERFACE)
# define BOOST_NETWORK_DLL_INTERFACE
#endif

#if !defined(BOOST_NETWORK_DLL_PRIVATE)
# define BOOST_NETWORK_DLL_PRIVATE
#endif

#if !defined(BOOST_ALL_NO_LIB) && !defined(BOOST_NETWORK_NO_LIB) && !defined(BOOST_NETWORK_SOURCE)
# define BOOST_LIB_NAME boost_network
# define BOOST_DYN_LINK
# include <boost/config/auto_link.hpp>
#endif

/**
 * Forward declarations of implementation defined types.
 *
 * These names must be only used to declare pointer/reference types.
 */
struct sockaddr;
struct addrinfo;

#endif // BOOST_NETWORK_DETAIL_CONFIG_HPP

