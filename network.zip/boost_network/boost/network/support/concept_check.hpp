// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(BOOST_NETWORK_CONCEPT_CHECKS_HPP)
#define BOOST_NETWORK_CONCEPT_CHECKS_HPP

namespace boost {

    namespace network {

        template <typename AddressT>
        class NetworkAddressConcept {
        public:

            void constraints () {
                a.family();
                a.address();
                a.length();
            }

        private:
            AddressT a;
        };

    }

}

#endif
