// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(BOOST_NETWORK_ADDRESS_HPP)
#define BOOST_NETWORK_ADDRESS_HPP

#include <boost/network/detail/config.hpp>

#include <memory>

#include <boost/network/net.hpp>

namespace boost {

    namespace network {
        
        /**
         * Forward declaration, in case we're not using the assignment
         * operator right now.
         */
        class resolved_address;

        class BOOST_NETWORK_DLL_INTERFACE generic_address {
        public:

            generic_address ();

            generic_address (generic_address const& that);

            generic_address (resolved_address const& that);

            ~generic_address ();

            net_base::family
            family () const;

            sockaddr const*
            address () const { return &*_M_address; }

            int
            length () const { return _M_length; }

            generic_address&
            operator= (generic_address const& that);

            generic_address&
            operator= (resolved_address const& that);

        private:
            int                           _M_length;
            std::auto_ptr<sockaddr const> _M_address;
        };
        
    }

}

#endif // BOOST_NETWORK_ADDRESS_HPP

