// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(BOOST_NETWORK_SOCKET_HPP)
#define BOOST_NETWORK_SOCKET_HPP

#include <boost/network/detail/config.hpp>

#include <boost/concept_check.hpp>
#include <boost/iostreams/categories.hpp>
#include <boost/noncopyable.hpp>
#include <boost/network/net.hpp>
#include <boost/network/support/concept_check.hpp>

namespace boost {

    namespace network {

        class listener;

        class BOOST_NETWORK_DLL_INTERFACE talker {
        public:
            
            typedef net_base::descriptor_type descriptor_type;
            
            typedef char char_type;
            typedef boost::iostreams::bidirectional_device_tag category;

            talker (net_base::family f);

            talker (listener& l);
            
            talker (talker const& t) : _M_d(t._M_d) {}

            ~talker () {}

            template <typename AddressT>
            void bind (AddressT const& a) {
                function_requires< NetworkAddressConcept<AddressT> >();
                this->bind(a.address(), a.length());
            }

            template <typename AddressT>
            void connect (AddressT const& a) {
                function_requires< NetworkAddressConcept<AddressT> >();
                this->connect(a.address(), a.length());
            }
            
            std::streamsize
            read (char* s, std::streamsize n);

            std::streamsize
            write (char const* s, std::streamsize n);

            void shutdown ();
            
            int
            peek ();

        private:

            void bind (sockaddr const* address, int length);

            void connect (sockaddr const* address, int length);

            descriptor_type _M_d;
        };

    }

}

#endif // BOOST_NETWORK_SOCKET_HPP

