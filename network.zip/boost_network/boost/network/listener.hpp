// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(BOOST_NETWORK_LISTENER_HPP)
#define BOOST_NETWORK_LISTENER_HPP

#include <boost/network/detail/config.hpp>

#include <boost/concept_check.hpp>
#include <boost/noncopyable.hpp>
#include <boost/network/net.hpp>
#include <boost/network/support/concept_check.hpp>

namespace boost {

    namespace network {

        class BOOST_NETWORK_DLL_INTERFACE listener
        : private boost::noncopyable {
        public:

            friend class talker;

            typedef net_base::descriptor_type descriptor_type;

            listener (net_base::family f);

            ~listener ();

            template <typename AddressT>
            void bind (AddressT const& a) {
                function_requires< NetworkAddressConcept<AddressT> >();
                this->bind(a.address(), a.length());
            }

            void listen ();

            void shutdown ();

        private:

            descriptor_type
            accept ();

            void
            bind (sockaddr const*, int length);

            descriptor_type _M_d;
        };

    }

}

#endif // BOOST_NETWORK_LISTENER_HPP

