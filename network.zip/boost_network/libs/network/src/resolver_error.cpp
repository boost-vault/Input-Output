// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_NETWORK_SOURCE

#include <boost/network/resolver_error.hpp>

#if defined(BOOST_WINDOWS)
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <netdb.h>
#endif

namespace boost {

    namespace network {

        resolver_error::resolver_error (int code)
        : std::runtime_error(gai_strerror(code)), _M_code(code) {}

    }

}

