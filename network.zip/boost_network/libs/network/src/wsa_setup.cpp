// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_NETWORK_SOURCE

#include <boost/network/support/wsa_setup.hpp>
#include <boost/network/net_error.hpp>

#if defined(BOOST_WINDOWS)

#include <winsock2.h>

namespace boost {

    namespace network {

        wsa_setup::wsa_setup ()
        : _M_wsaData( new WSAData ) {
            WSAData& wsaData = *_M_wsaData;

            WORD wVersionRequested = MAKEWORD( 2, 2 );
            int err = WSAStartup( wVersionRequested, &wsaData );
            if ( err != 0 )
                throw net_error();

            if ( LOBYTE( wsaData.wVersion ) != 2 ||
                 HIBYTE( wsaData.wVersion ) != 2 ) {
                WSACleanup( );
                throw net_error();
            }
        }

        wsa_setup::~wsa_setup () {
            WSACleanup();
        }

    }

}

#endif // BOOST_WINDOWS

