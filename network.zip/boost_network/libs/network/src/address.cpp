// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_NETWORK_SOURCE

#include <boost/network/address.hpp>

#include <cstring>

#include <boost/network/resolver.hpp>
#include <boost/network/detail/detail.hpp>

#if defined(BOOST_WINDOWS)
# include <winsock2.h>
#else
# include <sys/socket.h>
#endif

namespace boost {

    namespace network {

        generic_address::generic_address () : _M_length(0), _M_address() {}

        generic_address::generic_address (generic_address const& that)
        : _M_length(that.length()), _M_address(
            reinterpret_cast<sockaddr const*>(
              new char[_M_length]
              )
            ) {
            std::memcpy(const_cast<sockaddr*>(&*_M_address),
                        that.address(),
                        _M_length);
        }

        generic_address::generic_address (resolved_address const& that)
        : _M_length(that.length()), _M_address(
            reinterpret_cast<sockaddr const*>(
                new char[_M_length]
                )
            ) {
            std::memcpy(const_cast<sockaddr*>(&*_M_address),
                        that.address(),
                        _M_length);
        }

        generic_address::~generic_address () {}

        net_base::family
        generic_address::family () const {
            using namespace detail;
            return translate_family(_M_address->sa_family);
        }

        generic_address&
        generic_address::operator= (generic_address const& that) {
            _M_length = that.length();
            _M_address = std::auto_ptr<sockaddr const>(
                reinterpret_cast<sockaddr const*>(
                    new char[_M_length]
                    )
                );
            std::memcpy(const_cast<sockaddr*>(&*_M_address),
                        that.address(),
                        _M_length);
            return *this;
        }

        generic_address&
        generic_address::operator= (resolved_address const& that) {
            _M_length = that.length();
            _M_address = std::auto_ptr<sockaddr const>(
                reinterpret_cast<sockaddr const*>(
                    new char[_M_length]
                    )
                );
            std::memcpy(const_cast<sockaddr*>(&*_M_address),
                        that.address(),
                        _M_length);
            return *this;
        }

    }

}

