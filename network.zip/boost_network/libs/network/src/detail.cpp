// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_NETWORK_SOURCE

#include <boost/network/detail/detail.hpp>

#if defined(BOOST_WINDOWS)
# include <winsock2.h>
#else
# include <sys/socket.h>
#endif

namespace boost {

    namespace network {

        namespace detail {

            int
            translate_family (net_base::family f) {
                switch (f) {
                    case detail::_S_af_ipv4:
                        return AF_INET;
                    case detail::_S_af_ipv6:
                        return AF_INET6;
                    default:
                        return AF_UNSPEC;
                }
            }

            net_base::family
            translate_family (int f) {
                switch (f) {
                    case AF_INET:
                        return net_base::ipv4;
                    case AF_INET6:
                        return net_base::ipv6;
                    default:
                        return detail::_S_af_invalid;
                }
            }

        }

    }

}

