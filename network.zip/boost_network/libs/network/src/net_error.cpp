// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_NETWORK_SOURCE

#include <boost/network/net_error.hpp>

#if defined(BOOST_WINDOWS)
# include <sstream>
# include <algorithm>
# include <winsock2.h>
#else
# include <cerrno>
# include <cstring>
#endif

#if defined(BOOST_WINDOWS)
namespace {

    // Note that this list must remain sorted by the error constants'
    // values, because we do a binary search on the list when looking up
    // items.
    static struct ErrorEntry {
        int nID;
        const char* pcMessage;
        ErrorEntry (int id, const char* pc = 0) : nID(id), pcMessage(pc) { }
        bool operator< (const ErrorEntry& rhs) { return nID < rhs.nID; }
    } gaErrorList[] = {
        ErrorEntry(0,                  "No error"),
        ErrorEntry(WSAEINTR,           "Interrupted system call"),
        ErrorEntry(WSAEBADF,           "Bad file number"),
        ErrorEntry(WSAEACCES,          "Permission denied"),
        ErrorEntry(WSAEFAULT,          "Bad address"),
        ErrorEntry(WSAEINVAL,          "Invalid argument"),
        ErrorEntry(WSAEMFILE,          "Too many open sockets"),
        ErrorEntry(WSAEWOULDBLOCK,     "Operation would block"),
        ErrorEntry(WSAEINPROGRESS,     "Operation now in progress"),
        ErrorEntry(WSAEALREADY,        "Operation already in progress"),
        ErrorEntry(WSAENOTSOCK,        "Socket operation on non-socket"),
        ErrorEntry(WSAEDESTADDRREQ,    "Destination address required"),
        ErrorEntry(WSAEMSGSIZE,        "Message too long"),
        ErrorEntry(WSAEPROTOTYPE,      "Protocol wrong type for socket"),
        ErrorEntry(WSAENOPROTOOPT,     "Bad protocol option"),
        ErrorEntry(WSAEPROTONOSUPPORT, "Protocol not supported"),
        ErrorEntry(WSAESOCKTNOSUPPORT, "Socket type not supported"),
        ErrorEntry(WSAEOPNOTSUPP,      "Operation not supported on socket"),
        ErrorEntry(WSAEPFNOSUPPORT,    "Protocol family not supported"),
        ErrorEntry(WSAEAFNOSUPPORT,    "Address family not supported"),
        ErrorEntry(WSAEADDRINUSE,      "Address already in use"),
        ErrorEntry(WSAEADDRNOTAVAIL,   "Can't assign requested address"),
        ErrorEntry(WSAENETDOWN,        "Network is down"),
        ErrorEntry(WSAENETUNREACH,     "Network is unreachable"),
        ErrorEntry(WSAENETRESET,       "Net connection reset"),
        ErrorEntry(WSAECONNABORTED,    "Software caused connection abort"),
        ErrorEntry(WSAECONNRESET,      "Connection reset by peer"),
        ErrorEntry(WSAENOBUFS,         "No buffer space available"),
        ErrorEntry(WSAEISCONN,         "Socket is already connected"),
        ErrorEntry(WSAENOTCONN,        "Socket is not connected"),
        ErrorEntry(WSAESHUTDOWN,       "Can't send after socket shutdown"),
        ErrorEntry(WSAETOOMANYREFS,    "Too many references, can't splice"),
        ErrorEntry(WSAETIMEDOUT,       "Connection timed out"),
        ErrorEntry(WSAECONNREFUSED,    "Connection refused"),
        ErrorEntry(WSAELOOP,           "Too many levels of symbolic links"),
        ErrorEntry(WSAENAMETOOLONG,    "File name too long"),
        ErrorEntry(WSAEHOSTDOWN,       "Host is down"),
        ErrorEntry(WSAEHOSTUNREACH,    "No route to host"),
        ErrorEntry(WSAENOTEMPTY,       "Directory not empty"),
        ErrorEntry(WSAEPROCLIM,        "Too many processes"),
        ErrorEntry(WSAEUSERS,          "Too many users"),
        ErrorEntry(WSAEDQUOT,          "Disc quota exceeded"),
        ErrorEntry(WSAESTALE,          "Stale NFS file handle"),
        ErrorEntry(WSAEREMOTE,         "Too many levels of remote in path"),
        ErrorEntry(WSASYSNOTREADY,     "Network system is unavailable"),
        ErrorEntry(WSAVERNOTSUPPORTED, "Winsock version out of range"),
        ErrorEntry(WSANOTINITIALISED,  "WSAStartup not yet called"),
        ErrorEntry(WSAEDISCON,         "Graceful shutdown in progress"),
        ErrorEntry(WSAHOST_NOT_FOUND,  "Host not found"),
        ErrorEntry(WSANO_DATA,         "No host data of that type was found")
    };

    const int kNumMessages = sizeof(gaErrorList) / sizeof(ErrorEntry);

    //// WSAGetLastErrorMessage ////////////////////////////////////////////
    // A function similar in spirit to Unix's perror() that tacks a canned 
    // interpretation of the value of WSAGetLastError() onto the end of a
    // passed string, separated by a ": ".  Generally, you should implement
    // smarter error handling than this, but for default cases and simple
    // programs, this function is sufficient.
    std::string WSAGetLastErrorMessage (int nErrorID = 0)
    {
        std::ostringstream outs;

        // Tack appropriate canned message onto end of supplied message 
        // prefix. Note that we do a binary search here: gaErrorList must be
	    // sorted by the error constant's value.
	    ErrorEntry* pEnd = gaErrorList + kNumMessages;
        ErrorEntry Target(nErrorID ? nErrorID : WSAGetLastError());
        ErrorEntry* it = std::lower_bound(gaErrorList, pEnd, Target);
        if ((it != pEnd) && (it->nID == Target.nID)) {
            outs << it->pcMessage;
        }
        else {
            // Didn't find error in list, so make up a generic one
            outs << "Unknown error";
        }
        
        outs << " (" << Target.nID << ")";

        return outs.str();
    }


}
#endif

namespace boost {

    namespace network {

#if defined(BOOST_WINDOWS)

        net_error::net_error ()
        : std::runtime_error(WSAGetLastErrorMessage()), _M_code(WSAGetLastError()) {}

#else

        net_error::net_error ()
        : std::runtime_error(std::strerror(errno)), _M_code(errno) {}

#endif

    }

}

