// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(INTERNET_ABNF_HPP)
#define INTERNET_ABNF_HPP

#include <boost/spirit/core.hpp>

namespace internet {

    template <typename ScannerT>
    class abnf {
    public:

        typedef boost::spirit::rule<ScannerT> rule_t;

        abnf () {
            using namespace boost::spirit;

            ALPHA  = range_p(char(0x41), char(0x5A))
                   | range_p(char(0x61), char(0x7A));
            BIT    = ch_p('0') | '1';
            CHAR   = range_p(char(0x01), char(0x7F));
            CR     = ch_p(char(0x0D));
            CRLF   = CR >> LF;
            CTL    = range_p(char(0x00), char(0x1F)) | char(0x7F);
            DIGIT  = range_p(char(0x30), char(0x39));
            DQUOTE = ch_p(char(0x22));
            HEXDIG = DIGIT | 'A' | 'a' | 'B' | 'b' | 'C' | 'c' | 'D' | 'd'
                           | 'E' | 'e' | 'F' | 'f';
            HTAB   = ch_p(char(0x09));
            LF     = ch_p(char(0x0A));
            LWSP   = *(WSP | (CRLF >> WSP));
            OCTET  = range_p(char(0x00), char(0x7F))
                   | range_p(char(0x80), char(0xFF));
            SP     = ch_p(char(0x20));
            VCHAR  = range_p(char(0x21), char(0x7E));
            WSP    = SP | HTAB;
        }

    protected:
        rule_t ALPHA;
        rule_t BIT;
        rule_t CHAR;
        rule_t CR;
        rule_t CRLF;
        rule_t CTL;
        rule_t DIGIT;
        rule_t DQUOTE;
        rule_t HEXDIG;
        rule_t HTAB;
        rule_t LF;
        rule_t LWSP;
        rule_t OCTET;
        rule_t SP;
        rule_t VCHAR;
        rule_t WSP;
    };

}

#endif // INTERNET_ABNF_HPP

