// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(THREADED_SERVER_HPP)
#define THREADED_SERVER_HPP

#include <string>

#include <boost/network.hpp>
#include <boost/thread.hpp>

template <typename SessionT>
class threaded_server {
public:

    typedef void result_type;
    typedef SessionT session_type;

    threaded_server (std::string const& port)
    : _M_listener(boost::network::net_base::ipv4), _M_sessions() {
        using namespace boost::network;
        resolver r("", port);
        resolver::result_type::const_iterator i = r.result().begin();
        _M_listener.bind(*i);
    }

	void operator() () {
        typedef boost::network::netstream netstream;
        _M_listener.listen();
        while (true) {
            session_type s(_M_listener);
            _M_sessions.create_thread(s);
        }
    }

private:
    boost::network::listener _M_listener;
    boost::thread_group _M_sessions;
};

#endif // THREADED_SERVER_HPP
