// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(INTERNET_MESSAGE_HPP)
#define INTERNET_MESSAGE_HPP

#include <list>
#include <string>

#include <boost/spirit.hpp>

#include <abnf.hpp>

namespace internet {

    class message {
    public:

        typedef std::list<std::pair<std::string, std::string> > header_type;

        header_type const& header () const { return _M_header; }

        header_type& header () { return _M_header; }

        std::string const& body () const { return _M_body; }

        void body (std::string const& s) { _M_body = s; }

        void clear () {
            _M_header.clear();
            _M_body.clear();
        }

        template <typename IteratorT>
        boost::spirit::parse_info<IteratorT>
        parse (IteratorT const& begin, IteratorT const& end);

    private:
        header_type _M_header;
        std::string _M_body;
    };

    template <typename CharT, typename TraitsT>
    std::basic_ostream<CharT, TraitsT>&
    operator<< (std::basic_ostream<CharT, TraitsT>& o, message const& m) {
        message::header_type::const_iterator i = m.header().begin();
        for (; i != m.header().end(); ++i) {
            // Fold field as necessary. Iterative approach is most efficient.
            o << i->first << ": " << i->second << "\r\n";
        }

        if (!m.body().empty())
            o << "\r\n" << m.body();

        return o;
    }

    template <typename CharT, typename TraitsT>
    std::basic_istream<CharT, TraitsT>&
    operator>> (std::basic_istream<CharT, TraitsT>& i, message& m) {
        using namespace boost::spirit;

        typedef multi_pass<std::istreambuf_iterator<char> > iterator_t;
        iterator_t begin(i);
        iterator_t end = make_multi_pass(std::istreambuf_iterator<char>());

        parse_info<iterator_t> info = m.parse(begin, end);
        if (!info.hit)
            i.setstate(std::ios_base::failbit);

        return i;
    }

    namespace detail {

        using namespace boost::spirit;
        using namespace phoenix;

        class assign_body_a {
        public:
            assign_body_a (message& m) : ref(m) {}
            template <typename IteratorT>
            void operator() (IteratorT const& first,
                             IteratorT const& last) const {
                typedef std::string value_type;
                value_type vt(first, last);
                ref.body(vt);
            }
        private:
            message& ref;
        };

        struct string_c : public boost::spirit::closure<string_c, std::string> {
             member1 value;
        };

        struct field_c : public boost::spirit::closure<field_c,
                                std::pair<std::string, std::string>,
                                std::string, std::string> {
            member1 field;
            member2 name;
            member3 body;
        };

        class message_grammar : public grammar<message_grammar> {
        public:

            message_grammar (message& m) : _M_message(m) {}

            template <typename ScannerT>
            class definition : public internet::abnf<ScannerT> {
            public:

                typedef rule<ScannerT> rule_t;

                definition (message_grammar const& self) {

                    NO_WS_CTL = range_p(char(1), char(8))
                              | range_p(char(11), char(12))
                              | range_p(char(14), char(31))
                              | char(127);
                    text = range_p(char(1), char(9))
                         | range_p(char(11), char(12))
                         | range_p(char(14), char(127));

                    FWS = !( *WSP >> CRLF ) >> +WSP;

                    utext = NO_WS_CTL | range_p(char(33), char(126));
                    unstructured = *( !FWS >> utext ) >> !FWS;

                    internet::message& e = self._M_message;

                    message = fields >> !( CRLF >> body[ assign_body_a(e) ] );
                    body = *( *text >> CRLF ) >> *text;

                    fields = +( optional_field[ push_back_a(e.header()) ] );

                    optional_field = field_name[
                        optional_field.name = construct_<std::string>(arg1, arg2)
                    ] >> ':' >> unstructured[
                        optional_field.body = construct_<std::string>(arg1, arg2)
                    ] >> CRLF[
                        optional_field.field =
                            construct_<std::pair<std::string, std::string> >(
                                    optional_field.name,
                                    optional_field.body
                                    )
                    ];
                    field_name = +ftext;
                    ftext = range_p(char(33), char(57))
                          | range_p(char(59), char(126));
                }

                rule_t const& start () const {
                    return message;
                }

            protected:
                using internet::abnf<ScannerT>::CRLF;
                using internet::abnf<ScannerT>::WSP;
            private:

                rule_t NO_WS_CTL;
                rule_t text;
/*
                rule_t specials;

                rule_t quoted_pair;
*/
                rule_t FWS;
/*
                rule_t ctext;
                rule_t ccontent;
                rule_t comment;
                rule_t CFWS;

                rule_t atext;
                rule_t atom;
                rule_t dot_atom;
                rule_t dot_atom_text;

                rule_t qtext;
                rule_t qcontent;
                rule_t quoted_string;

                rule_t word;
                rule_t phrase;
*/
                rule_t utext;
                rule_t unstructured;
/*
                rule_t date_time;
                rule_t day_of_week;
                rule_t day_name;
                rule_t date;
                rule_t year;
                rule_t month;
                rule_t month_name;
                rule_t day;
                rule_t time;
                rule_t time_of_day;
                rule_t hour;
                rule_t minute;
                rule_t second;
                rule_t zone;

                rule_t address;
                rule_t mailbox;
                rule_t name_addr;
                rule_t angle_addr;
                rule_t group;
                rule_t display_name;
                rule_t mailbox_list;
                rule_t address_list;

                rule_t addr_spec;
                rule_t local_part;
                rule_t domain;
                rule_t domain_literal;
                rule_t dcotent;
                rule_t dtext;
*/
                rule_t message;
                rule_t body;

                rule_t fields;
/*
                rule_t orig_date;

                rule_t from;
                rule_t sender;
                rule_t reply_to;

                rule_t to;
                rule_t cc;
                rule_t bcc;

                rule_t message_id;
                rule_t in_reply_to;
                rule_t references;
                rule_t msg_id;
                rule_t id_left;
                rule_t id_right;
                rule_t no_fold_quote;
                rule_t no_fold_literal;

                rule_t subject;
                rule_t comments;
                rule_t keywords;

                rule_t resent_date;
                rule_t resent_from;
                rule_t resent_sender;
                rule_t resent_to;
                rule_t resent_cc;
                rule_t resent_bcc;
                rule_t resent_msg_id;

                rule_t trace;
                rule_t _return;
                rule_t path;
                rule_t received;
                rule_t name_val_list;
                rule_t name_val_pair;
                rule_t item_name;
                rule_t item_value;
*/
                rule<ScannerT, field_c::context_t> optional_field;
                rule_t field_name;
                rule_t ftext;

            };

        private:

            message mutable& _M_message;

        };

    }

    template <typename IteratorT>
    boost::spirit::parse_info<IteratorT>
    message::parse (IteratorT const& begin, IteratorT const& end) {
        using namespace boost::spirit;
        this->clear();
        detail::message_grammar grammar(*this);
        parse_info<IteratorT> info = boost::spirit::parse(begin, end, grammar);
        // Validate? Unfold?
        return info;
    }

}

#endif // INTERNET_MESSAGE_HPP

