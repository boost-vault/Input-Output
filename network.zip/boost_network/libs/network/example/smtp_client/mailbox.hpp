// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(INTERNET_MAILBOX_HPP)
#define INTERNET_MAILBOX_HPP

#include <string>

#include <boost/spirit.hpp>

#include <abnf.hpp>

namespace internet {

    class mailbox {
    public:
    
        std::string const& display_name () const { return _M_display_name; }
        
        void display_name (std::string const& s) { _M_display_name = s; }
        
        std::string const& addr_spec () const { return _M_addr_spec; }
        
        void addr_spec (std::string const& s) { _M_addr_spec = s; }

        void clear () {
            _M_display_name.clear();
            _M_addr_spec.clear();
        }

        template <typename IteratorT>
        boost::spirit::parse_info<IteratorT>
        parse (IteratorT const& begin, IteratorT const& end);

    private:
        std::string _M_display_name;
        std::string _M_addr_spec;
    };

    namespace detail {

        using namespace boost::spirit;
        using namespace phoenix;

        class assign_display_name_a {
        public:
            assign_display_name_a (mailbox& mb) : ref(mb) {}
            template <typename IteratorT>
            void operator() (IteratorT const& first,
                             IteratorT const& last) const {
                ref.display_name(std::string(first, last));
            }
        private:
            mailbox& ref;
        };

        class assign_addr_spec_a {
        public:
            assign_addr_spec_a (mailbox& mb) : ref(mb) {}
            template <typename IteratorT>
            void operator() (IteratorT const& first,
                             IteratorT const& last) const {
                ref.addr_spec(std::string(first, last));
            }
        private:
            mailbox& ref;
        };

        class mailbox_grammar : public boost::spirit::grammar<mailbox_grammar> {
        public:

            mailbox_grammar (mailbox& mb) : _M_mb(mb) {}

            template <typename ScannerT>
            class definition : public internet::abnf<ScannerT> {
            public:

                typedef rule<ScannerT> rule_t;

                definition (mailbox_grammar const& self) {
                    NO_WS_CTL = range_p(char(1), char(8))
                              | range_p(char(11), char(12))
                              | range_p(char(14), char(31))
                              | char(127);
                    text = range_p(char(1), char(9))
                         | range_p(char(11), char(12))
                         | range_p(char(14), char(127));

                    quoted_pair = '\\' >> text;

                    FWS = !( *WSP >> CRLF ) >> +WSP;
                    ctext = NO_WS_CTL | range_p(char(33), char(39))
                                      | range_p(char(42), char(91))
                                      | range_p(char(93), char(126));
                    ccontent = ctext | quoted_pair | comment;
                    comment = '(' >> *(!FWS >> ccontent) >> !FWS >> ')';
                    CFWS = *(!FWS >> comment) >> ((!FWS >> comment) | FWS);

                    atext = ALPHA | DIGIT | '!' | '#' | '$' | '%' | '&'
                       | char(92) | '*' | '+' | '-' | '/' | '=' | '?' | '^'
                       | '_' | char(91) | '{' | '|' | '}' | '~';
                    atom = !CFWS >> +atext >> !CFWS;
                    dot_atom = !CFWS >> dot_atom_text >> !CFWS;
                    dot_atom_text = +atext >> *('.' >> +atext);

                    qtext = NO_WS_CTL | char(33) | range_p(char(35), char(91))
                                      | range_p(char(93), char(126));
                    qcontent = qtext | quoted_pair;
                    quoted_string = !CFWS >> DQUOTE >> *(!CFWS >> qcontent)
                                 >> !FWS >> DQUOTE >> !CFWS;

                    word = atom | quoted_string;
                    phrase = +word;

                    internet::mailbox& mb = self._M_mb;

                    mailbox = name_addr | addr_spec[ assign_addr_spec_a(mb) ];
                    name_addr = !display_name[ assign_display_name_a(mb) ]
                             >> angle_addr;
                    angle_addr = !CFWS >> '<'
                              >> addr_spec[ assign_addr_spec_a(mb) ]
                              >> '>' >> !CFWS;
                    display_name = phrase;

                    addr_spec = local_part >> '@' >> domain;
                    local_part = dot_atom | quoted_string;
                    domain = dot_atom | domain_literal;
                    domain_literal = !CFWS >> '[' >> *(!FWS >> dcontent)
                                  >> !FWS >> ']' >> !CFWS;
                    dcontent = dtext | quoted_pair;
                    dtext = NO_WS_CTL | range_p(char(33), char(90))
                                      | range_p(char(94), char(126));
                }

                rule_t const& start () const { return mailbox; }

            protected:
                using internet::abnf<ScannerT>::ALPHA;
                using internet::abnf<ScannerT>::CRLF;
                using internet::abnf<ScannerT>::DIGIT;
                using internet::abnf<ScannerT>::DQUOTE;
                using internet::abnf<ScannerT>::WSP;
            private:
                rule_t NO_WS_CTL;
                rule_t text;

                rule_t quoted_pair;

                rule_t FWS;
                rule_t ctext;
                rule_t ccontent;
                rule_t comment;
                rule_t CFWS;

                rule_t atext;
                rule_t atom;
                rule_t dot_atom;
                rule_t dot_atom_text;

                rule_t qtext;
                rule_t qcontent;
                rule_t quoted_string;

                rule_t word;
                rule_t phrase;

                rule_t mailbox;
                rule_t name_addr;
                rule_t display_name;
                rule_t angle_addr;

                rule_t addr_spec;
                rule_t local_part;
                rule_t domain;
                rule_t domain_literal;
                rule_t dcontent;
                rule_t dtext;
            };

        private:
            mailbox mutable& _M_mb;
        };

    }

    template <typename IteratorT>
    boost::spirit::parse_info<IteratorT>
    mailbox::parse (IteratorT const& begin, IteratorT const& end) {
        using namespace boost::spirit;
        this->clear();
        detail::mailbox_grammar grammar(*this);
        parse_info<IteratorT> info = boost::spirit::parse(begin, end, grammar);
        return info;
    }

}

#endif // INTERNET_MAILBOX_HPP

