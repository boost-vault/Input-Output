// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(INTERNET_SMTP_TRANSACTION_HPP)
#define INTERNET_SMTP_TRANSACTION_HPP

#include <iosfwd>
#include <list>
#include <string>

#include <boost/io/ios_state.hpp>

namespace internet {

    class smtp_transaction {
    public:

        typedef std::list<std::string> recipient_type;

        std::string const& identity () const { return _M_identity; }

        void identity (std::string const& s) { _M_identity = s; }

        std::string const& sender () const { return _M_sender; }

        void sender (std::string const& s) { _M_sender = s; }

        std::list<std::string> const& recipient () const { return _M_recipient; }

        std::list<std::string>& recipient () { return _M_recipient; }

        internet::message const& message () const { return _M_message; }

        void message (internet::message const& m) { _M_message = m; }

    private:
        std::string       _M_identity;
        std::string       _M_sender;
        recipient_type    _M_recipient;
        internet::message _M_message; // Ugh!
    };

    template <typename CharT, typename TraitsT>
    std::basic_iostream<CharT, TraitsT>&
    operator& (std::basic_iostream<CharT, TraitsT>& io,
               smtp_transaction& s) {
        using namespace std;
        
        boost::io::ios_all_saver ias(io);
        io.tie(&io);
        // Turn exceptions on; try-catch.

        string response;
        getline(io, response);
        if (response[0] != '2') {
            io.setstate(ios_base::failbit);
            return io;
        }

        io << "HELO " << s.identity() << "\r\n";

        getline(io, response);
        if (response[0] != '2') {
            io.setstate(ios_base::failbit);
            return io;
        }

        io << "MAIL FROM: <" << s.sender() << ">\r\n";

        getline(io, response);
        if (response[0] != '2') {
            io.setstate(ios_base::failbit);
            return io;
        }

        for (smtp_transaction::recipient_type::const_iterator i = s.recipient().begin();
             i != s.recipient().end();
             ++i) {
            io << "RCPT TO: <" << *i << ">\r\n";
            getline(io, response);
            if (response[0] != '2') {
            io.setstate(ios_base::failbit);
                return io;
            }
        }

        io << "DATA\r\n";

        getline(io, response);
        if (response[0] != '3') {
            io.setstate(ios_base::failbit);
            return io;
        }

        io << s.message() << "\r\n.\r\n";

        getline(io, response);
        if (response[0] != '2') {
            io.setstate(ios_base::failbit);
            return io;
        }

        io << "QUIT\r\n";

        getline(io, response);
        if (response[0] != '2') {
            io.setstate(ios_base::failbit);
            return io;
        }

        return io;
    }

}

#endif // INTERNET_SMTP_TRANSACTION_HPP
