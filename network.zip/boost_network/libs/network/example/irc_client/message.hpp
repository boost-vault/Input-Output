// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(IRC_MESSAGE_HPP)
#define IRC_MESSAGE_HPP

#include <iosfwd>
#include <list>

#include <boost/spirit.hpp>

#include <abnf.hpp>

namespace irc {

    /**
     * @brief A message in the IRC protocol.
     */
    class message {
    public:

        typedef std::list<std::string> arguments_t;

        message ()
        : _M_prefix(), _M_command(), _M_arguments(), _M_payload() {}

        message (std::string const& s)
        : _M_prefix(), _M_command(), _M_arguments(), _M_payload() {
            parse(s.begin(), s.end());
        }

        std::string const& prefix () const { return _M_prefix; }

        void prefix (std::string const& s) { _M_prefix = s; }

        std::string const& command () const { return _M_command; }

        void command (std::string const& s) { _M_command = s; }

        arguments_t const& arguments () const { return _M_arguments; }

        arguments_t& arguments () { return _M_arguments; }

        std::string const& payload () const { return _M_payload; }

        void payload (std::string const& s) { _M_payload = s; }

        template <typename IteratorT>
        boost::spirit::parse_info<IteratorT>
        parse (IteratorT begin, IteratorT end);

        void clear () {
            _M_prefix.clear();
            _M_command.clear();
            _M_arguments.clear();
            _M_payload.clear();
        }

    private:
    
        std::string _M_prefix;
        std::string _M_command;
        arguments_t _M_arguments;
        std::string _M_payload;
    };

    template <typename CharT, typename TraitsT>
    std::basic_ostream<CharT, TraitsT>&
    operator<< (std::basic_ostream<CharT, TraitsT>& o, message const& m) {

        if (!m.prefix().empty())
            o << ':' << m.prefix() << ' ';

        o << m.command();

        for (message::arguments_t::const_iterator i = m.arguments().begin();
            i != m.arguments().end();
            ++i)
                o << ' ' << *i;

        if (!m.payload().empty())
            o << " :" << m.payload();

        return o << "\r\n";
    }

    template <typename CharT, typename TraitsT>
    std::basic_istream<CharT, TraitsT>&
    operator>> (std::basic_istream<CharT, TraitsT>& i, message& m) {
        using namespace boost::spirit;

        typedef multi_pass<std::istreambuf_iterator<char> > iterator_t;
        iterator_t begin(i);
        iterator_t end = make_multi_pass(std::istreambuf_iterator<char>());

        parse_info<iterator_t> info = m.parse(begin, end);
        if (!info.hit)
            i.setstate(std::ios_base::failbit);

        return i;
    }

    namespace detail {

        using namespace boost::spirit;
        using namespace phoenix;

        class assign_prefix_action {
        public:

            template <typename T, typename ValueT>
            void act (T& ref, ValueT const& value) const {
                ref.prefix(value);
            }

            template <typename T, typename IteratorT>
            void act (T& ref, IteratorT const& first,
                      IteratorT const& last) const {
                typedef std::string value_type;
                value_type vt(first, last);
                ref.prefix(vt);
            }

        };

        class assign_command_action {
        public:

            template <typename T>
            void act (T& ref, std::string const& s) const {
                ref.command(s);
            }

            template <typename T, typename IteratorT>
            void act (T& ref, IteratorT const& first,
                      IteratorT const& last) const {
                std::string s(first, last);
                ref.command(s);
            }

        };

        class assign_payload_action {
        public:

            template <typename T, typename ValueT>
            void act (T& ref, ValueT const& value) const {
                ref.payload(value);
            }

            template <typename T, typename IteratorT>
            void act (T& ref, IteratorT const& first,
                      IteratorT const& last) const {
                typedef std::string value_type;
                value_type vt(first, last);
                ref.payload(vt);
            }

        };

        template <typename T>
        inline ref_value_actor<T, assign_prefix_action>
        assign_prefix_a (T& ref) {
            return ref_value_actor<T, assign_prefix_action>(ref);
        }

        template <typename T>
        inline ref_value_actor<T, assign_command_action>
        assign_command_a (T& ref) {
            return ref_value_actor<T, assign_command_action>(ref);
        }

        template <typename T>
        inline ref_value_actor<T, assign_payload_action>
        assign_payload_a (T& ref) {
            return ref_value_actor<T, assign_payload_action>(ref);
        }

        /**
         * @brief Grammar for the serialized form of the message.
         */
        class grammar : public boost::spirit::grammar<grammar> {
        public:

            grammar (message& m) : _M_message(m) {}

            template <typename ScannerT>
            class definition : public internet::abnf<ScannerT> {
            public:

                typedef rule<ScannerT> rule_t;

                definition(grammar const& self) {

                    irc::message& m = self._M_message;

                    // Brain-dead IRCDs put that extra LF
                    message = !( ':'  >> prefix[ assign_prefix_a(m)	] >> SP )
                                >> command[ assign_command_a(m) ]
                                >> !params >> !LF/*SIC*/ >> CRLF;

                    // This order is important: servername and nickname are
                    // ambiguous; we hack around it.
                    prefix = servername
                       || ( nickname >> !( !( '!' >> user ) >> '@' >> host ) );

                    command = +ALPHA || ( DIGIT >> DIGIT >> DIGIT );

                    message::arguments_t& at = m.arguments();

                    params = ( *( SP >> middle[ push_back_a(at) ] )
                            >> !( SP >> !ch_p(':') >>
                                trailing[ assign_payload_a(m) ] ) )
                        || ( *( SP >> middle[ push_back_a(at) ] )
                            >> !( SP >> trailing[ assign_payload_a(m) ] ) );

					nospcrlfcl = range_p(char(0x01), char(0x09))
					          || range_p(char(0x0B), char(0x0C))
                              || range_p(char(0x0E), char(0x1F))
                              || range_p(char(0x21), char(0x39))
                              || range_p(char(0x3B), char(0x7F))
                              || range_p(char(0x80), char(0xFF));
                    middle = nospcrlfcl >> *( ':' || nospcrlfcl );
                    trailing = *( ch_p(':') || ' ' || nospcrlfcl );

                    servername = hostname;
                    host = hostname || hostaddr;
                    // We hack the definition to disambiguate the grammar.
                    hostname = shortname >> +/*SIC*/( ch_p('.') >> shortname );
                    shortname = ( ALPHA || DIGIT )
					   >> *( ALPHA || DIGIT || ch_p('-') )
                       >> *( ALPHA || DIGIT );

                    hostaddr = ip4addr || ip6addr;
                    ip4addr = DIGIT >> !DIGIT >> !DIGIT >> '.'
                        >> DIGIT >> !DIGIT >> !DIGIT >> '.'
						>> DIGIT >> !DIGIT >> !DIGIT >> '.'
						>> DIGIT >> !DIGIT >> !DIGIT;
                    ip6addr = ( +HEXDIG >> ':' >> +HEXDIG >> ':'
                        >> +HEXDIG >> ':' >> +HEXDIG >> ':' >> +HEXDIG >> ':'
                        >> +HEXDIG >> ':' >> +HEXDIG >> ':' >> +HEXDIG )
                        || ( str_p("0:0:0:0:0:") >> ( ch_p('0') || "FFFF" )
                        >> ':' >> ip4addr );
                    nickname = ( ALPHA || special ) >>
                        *( ALPHA || DIGIT || special || '-' );

                    user = +( range_p(char(0x01), char(0x09))
                           || range_p(char(0x0B), char(0x0C))
                           || range_p(char(0x0E), char(0x1F))
                           || range_p(char(0x21), char(0x3F))
                           || range_p(char(0x41), char(0x7F))
                           || range_p(char(0x80), char(0xFF)) );
                    special = range_p(char(0x5B), char(0x60))
                           || range_p(char(0x7B), char(0x7D));
                }

                rule<ScannerT> const& start() const {
                    return message;
                }

            protected:
                using internet::abnf<ScannerT>::ALPHA;
                using internet::abnf<ScannerT>::SP;
                using internet::abnf<ScannerT>::CRLF;
                using internet::abnf<ScannerT>::DIGIT;
                using internet::abnf<ScannerT>::HEXDIG;
                using internet::abnf<ScannerT>::LF;
            private:
                rule_t message;
                rule_t prefix;
                rule_t command;
                rule_t params;
                rule_t nospcrlfcl;
                rule_t middle;
                rule_t trailing;

                rule_t servername;
                rule_t host;
                rule_t hostname;
                rule_t shortname;
                rule_t hostaddr;
                rule_t ip4addr;
                rule_t ip6addr;
                rule_t nickname;

                rule_t user;

                rule_t special;
            };

        private:
            message mutable& _M_message;
        };

    }

    template <typename IteratorT>
    boost::spirit::parse_info<IteratorT>
    message::parse (IteratorT begin, IteratorT end) {
        using namespace boost::spirit;
        this->clear();
        detail::grammar g(*this);
        return boost::spirit::parse(begin, end, g);
    }

}

#endif // IRC_MESSAGE_HPP

