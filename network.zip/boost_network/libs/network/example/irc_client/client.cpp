// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_ALL_NO_LIB

#include <client.hpp>

#include <algorithm>
#include <functional>

#include <boost/network.hpp>

using namespace boost::network;

namespace irc {

	client::client (configuration const& c) 
    : _M_configuration(c), _M_signal(), _M_connection(net_base::ipv4) {}
	
	class printer {
	public:
	
		printer (std::ostream& os) : o(os) {}
		printer (printer const& p) : o(p.o) {}

		typedef void result_type;
		typedef std::string const& argument_type;

		void operator() (std::string const& s) {
			o << ' ' << s;
		}
		
	private:
		std::ostream& o;
	};

	void client::operator() () {

		if (_M_configuration.servers().empty())
			return;
		char const* tmp = _M_configuration.servers().begin()->c_str();

		resolver r;
		r.resolve(tmp, "ircd");
        resolver::result_type::const_iterator i = r.result().begin();

		netstream& s = _M_connection;
		s->connect(*i);

		s << "NICK " << _M_configuration.nickname() << "\r\n";
		s << "USER " << _M_configuration.username() << " "
		<< _M_configuration.mode() << " * :"
		<< _M_configuration.realname() << "\r\n" << std::flush;

		if (!_M_configuration.channels().empty()) {
			s << "JOIN";

			printer p(s);
			std::for_each(_M_configuration.channels().begin(),
							_M_configuration.channels().end(),
							p);

			s << "\r\n" << std::flush;
		}

		irc::message m;
		while (s >> m) {
			_M_signal(m, proxy(*this));
		}

		s->shutdown();
	}

}
