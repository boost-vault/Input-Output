// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_ALL_NO_LIB

#include <configuration.hpp>

namespace irc {

	configuration::configuration ()
	: _M_servers(), _M_nickname("irc_nick"), _M_username("irc_user"),
	_M_mode(8), _M_realname("Real Name"), _M_channels(), _M_password() {
		_M_servers.push_back(std::string("irc.freenode.org"));
		_M_channels.push_back(std::string("#mndfck"));
	}

}
