// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_ALL_NO_LIB

#include <bot.hpp>

#include <iostream>

#include <message.hpp>

namespace irc {
	
	bot::bot (configuration const& c) : _M_client(c) {}
	
	struct log_module {
		typedef void result_type;
		typedef message const& argument_type;
		void operator() (message const& m, client::proxy p) {
			std::cout << ">> " << m << std::flush;
		}
	};
	
	struct ping_pong_module {
		typedef void result_type;
		typedef message const& argument_type;
		void operator() (message const& m, client::proxy p) {
			if (m.command() == "PING") {
				pong.arguments().clear();
				pong.arguments().push_back(m.payload());
				p.send(pong).flush();
				std::cout << "<< " << pong << std::flush;
			}
		}
		static message pong;
	};
	
	message ping_pong_module::pong("PONG"); // FIXME: see default constructor

	void bot::operator() () {

		_M_client.signal().connect(log_module());
		_M_client.signal().connect(ping_pong_module());
		_M_client();

	}

}
