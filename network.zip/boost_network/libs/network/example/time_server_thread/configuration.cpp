#include <boost/program_options.hpp>

#include <configuration.hpp>

using namespace std;
namespace po = boost::program_options;

configuration::configuration (std::string const& default_port)
: _M_must_help(false), _M_port(default_port) {}

void
configuration::parse_command_line (int argc, char* argv[]) {
    po::options_description desc("Allowed options");
    desc.add_options()
        ("help", "produce help message")
        ("port,p",po::value<string>(&_M_port), "port number or service name")
        ;

    po::variables_map vm;
    po::store(po::parse_command_line(argc, argv, desc), vm);
    po::notify(vm);    

    if (vm.count("help")) {
        _M_must_help = true;
    }
}
