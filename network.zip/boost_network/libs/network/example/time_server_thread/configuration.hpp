#ifndef CONFIGURATION_HPP_
#define CONFIGURATION_HPP_

#include <string>

class configuration {
public:

    configuration (std::string const& default_port);
    
    void
    parse_command_line (int argc, char* argv[]);
    
    bool
    must_help () const { return _M_must_help; }
    
    std::string const&
    port () const { return _M_port; }

private:
    bool _M_must_help;
    std::string _M_port;
};

#endif /*CONFIGURATION_HPP_*/
