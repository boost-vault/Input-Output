// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <iostream>

#include <boost/shared_ptr.hpp>
#include <boost/network.hpp>
#include <boost/tokenizer.hpp>

#include <session.hpp>
#include <http_request.hpp>

using namespace std;
using namespace boost;
using namespace http;

void session::operator() () {
    http_request req;
    *_M_conn >> req;

    string s = req.request();
    tokenizer<> t(s);

    for (tokenizer<>::const_iterator i = t.begin(); i != t.end(); ++i)
        std::cout << *i << std::endl;

    (*_M_conn)->shutdown();
}
