// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#if !defined(CHARGEN_SESSION_HPP)
#define CHARGEN_SESSION_HPP

#include <boost/shared_ptr.hpp>
#include <boost/network.hpp>

namespace chargen {

    class session {
    public:

        typedef void result_type;

        session (boost::network::listener& l)
        : s("!\"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^"
            "_`abcdefghijklmnopqrstuvwxyz{|}~ "),
          _M_conn(new boost::network::netstream(l)) {}

        // What happend when the other end shuts down? This thread never ends.
        void operator() () {
            for (int l = 0; ; l = (l + 1) % 71) {
                for (int i = l; i <= l + 71; i++)
                    if (!_M_conn->put(s[i % 95]))
                        return;
                if (!_M_conn->put('\r'))
                    return;
                if (!_M_conn->put('\n'))
                    return;
            }
            
            (*_M_conn)->shutdown();
        }

    private:
        char const* s;
        boost::shared_ptr<boost::network::netstream> _M_conn;
    };

}

#endif // CHARGEN_SESSION_HPP
