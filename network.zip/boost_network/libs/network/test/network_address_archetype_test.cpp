// Copyright 2005 Pedro Lamarão.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/concept_check.hpp>
#include <boost/network/listener.hpp>
#include <boost/network/netstream.hpp>
#include <boost/network/net.hpp>
#include <boost/network/support/concept_check.hpp>

using namespace boost;
using namespace boost::network;

class network_address_archetype {
public:

    net_base::family
    family () const { return net_base::family(0); }

    sockaddr const*
    address () const { return 0; }

    int
    length () const { return 0; }

};

int main (int argc, char* argv[]) {

    function_requires< NetworkAddressConcept<network_address_archetype> >();

    network_address_archetype a;

    try {
      netstream s(net_base::ipv4);
      s.connect(a);
    } catch (...) {}

    try {
      listener l(net_base::ipv4);
      l.bind(a);
    } catch (...) {}

    return 0;

}
